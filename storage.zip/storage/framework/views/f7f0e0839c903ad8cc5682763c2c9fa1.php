

<?php $__env->startSection('page_content'); ?>
    <div class="container-fluid content-inner pb-0">
        <div class="row pt-2">
            <div class="col-lg-4">
                <div class="card card-block card-stretch custom-scroll">
                    <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-3">
                        <div class="caption">
                            <h4 class="font-weight-bold mb-2">Buy Prime Coin</h4>
                        </div>
                    </div>
                    <div class="card-body">



                        <div class="d-flex justify-content-start mb-2 gap-2">
                            <span class="fs-6 fw-bold me-2">1 USDT = <?php echo e($rate); ?> PC</span>
                        </div>



                        <div class="card shining-card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="d-flex align-items-center gap-2">
                                        <img src="<?php echo e(asset('assets/images/coins/01.png')); ?>"
                                            class="img-fluid avatar avatar-30 avatar-rounded" style="width: 30px">
                                        <span class="fs-6 fw-bold me-2" style="line-height: 20px">USDT balance <br>
                                            <span style="font-weight: lighter"> <?php echo e(number_format($usdt_balance, 2)); ?>

                                                <small>USDT</small> </span></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php
                            $price = coinTotalPurchase(auth()->user()->id);
                        ?>

                        <?php if($price > 0): ?>
                            <div class="d-flex justify-content-start mb-2 gap-2">
                                <small class=" me-2">Maximum Purchase Left = $ <?php echo e(number_format(15000 - $price)); ?> </small>
                            </div>
                        <?php else: ?>
                            <div class="d-flex justify-content-start mb-2 gap-2">
                                <span class="fs-6  me-2">Minimum Purchase = $20 </span>
                            </div>
                        <?php endif; ?>





                        <form method="post" id="buypmc" action="<?php echo e(route('buy_primecoin')); ?>"><?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="text"> Amount In USDT </label>
                                <input type="number" name="usdt_amount" class="form-control" min="20"
                                    max="<?php echo e($usdt_balance); ?>" name="usdt" id="usdt" value="<?php echo e(old('wallet')); ?>">
                                <?php $__errorArgs = ['wallet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <i class="text-danger "><?php echo e($message); ?> </i>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group">
                                <label for="amount">Amount In PC</label>
                                <input type="number" class="form-control" name="pc" id="pc" readonly>
                            </div>

                            <div class="d-flex justify-content-end ">
                                <button type="submit" class="btn buypmcbtn btn-primary">Buy</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-8">
                <div class="card card-block card-stretch custom-scroll">
                    <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-3">
                        <div class="caption">
                            <h4 class="font-weight-bold mb-2">Purchase History</h4>
                        </div>
                    </div>
                    <div class="card-body">


                        <div class="row" >
                            <div class="card border-bottom border-4 border-0 border-warning col-md-6 ">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <span>Royalty Strength </span>
                                        </div>
                                        <div>
                                            <span class="counter" style="visibility: visible;"> $ <?php echo e(number_format($price)); ?>

                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="card border-bottom border-4 border-0 border-success col-md-6">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <span>Royalty Benchmark </span>
                                        </div>
                                        <div>
                                            <span class="counter" style="visibility: visible;"> $
                                                <?php echo e(number_format(15000 - $price)); ?> </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table data-table mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col">USDT</th>
                                        <th scope="col">Rate</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">PC</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Timestamp</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td> <?php echo e($pur->amount); ?> USDT </td>
                                            <td> <?php echo e($pur->rate); ?>/USDT </td>
                                            <td> $ <?php echo e(number_format(1 / $pur->rate, 2)); ?> </td>
                                            <td> <?php echo e(number_format($pur->amount * $pur->rate, 2)); ?> PC </td>
                                            <td>
                                                <div class="badge  bg-success">
                                                    successful
                                                </div>
                                            </td>
                                            <th><?php echo e($pur->created_at); ?></th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
    <script>
        $(function() {

            // $('#pc').on('keyup', function() {
            //     pc = $('#pc');
            //     usdt = $('#usdt');
            //     coin = parseInt(pc.val());
            //     $.ajax({
            //         method: 'get',
            //         url: '/get_price'
            //     }).done(function(res) {
            //         price = coin / res.price
            //         usdt.val(price)
            //     }).fail(function(res) {
            //         console.log(res);
            //     })
            // })


            $('#buypmc').on('submit', function() {
                $('.buypmcbtn').attr('disabled', 'disabled');
            })


            $('#usdt').on('keyup', function() {
                usdt = $('#usdt');
                amt_usdt = parseInt(usdt.val());
                $.ajax({
                    method: 'get',
                    url: '/get_price'
                }).done(function(res) {
                    price = amt_usdt * res.price

                    price = (price == NaN) ? 0 : price;

                    $('#pc').val(price)
                }).fail(function(res) {
                    console.log(res);
                })
            })

        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prime-coin\resources\views/users/convert.blade.php ENDPATH**/ ?>