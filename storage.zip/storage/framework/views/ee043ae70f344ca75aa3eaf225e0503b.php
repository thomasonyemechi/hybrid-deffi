
<?php $__env->startSection('page_content'); ?>
    <div class="container-fluid content-inner pb-0">
        <div class="row mb-4">
            <div class="col-lg-12">

                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title text-white">Basic Datatable</h4>
                        </div>
                        <div class="d-flex mt-3 ms-4 me-4 justify-content-between">

                            <div class="form-outline">
                                <form action="">
                                    <input type="search" name="user" class="form-control ms-1" placeholder="Search users.."
                                    aria-label="Search">
                                </form>
                            </div>
                        </div>
                        <div class="card-body">
                            <?php echo ($_GET['user']) ? '<p class="mb-2 fw-bold" >Search Result for <b>" '.$_GET['user'].' "</b></p>' : ''; ?>

                            <div class="table-responsive">
                                <table class="table">
                                    <thead class="">
                                        <tr>
                                            <th>Username</th>
                                            <th>PC</th>
                                            <th>USDT</th>
                                            <th>SPC</th>
                                            <th>Purchase</th>
                                            <th>Reffered By</th>
                                            <th>Joined</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td> <a class=" fw-bold " href="/admin/user/<?php echo e($user->id); ?>"  > <span><?php echo e($user->username); ?> </span> </a> </td>
                                                <td> <?php echo e(number_format(pcBalance($user->id),)); ?> PC </td>
                                                <td> <?php echo e(number_format(usdtBalance($user->id),)); ?> USDT </td>
                                                <td> <?php echo e(number_format(spcBalance($user->id),)); ?> SPC </td>
                                                <td> <?php echo e(number_format(coinTotalPurchase($user->id),)); ?> USDT </td>
                                                <td> 
                                                    <?php echo e(($user->spon) ? $user->spon->username : 'Admin'); ?>

                                                </td>
                                                <td> <?php echo e(date('j M, Y', strtotime($user->created_at))); ?> </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                                <div class="d-flex justify-content-between flex-wrap">
                                    <?php echo e($users->links('pagination::bootstrap-4')); ?>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prime-coin\resources\views/admin/users.blade.php ENDPATH**/ ?>