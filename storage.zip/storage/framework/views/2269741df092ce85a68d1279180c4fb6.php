
<?php $__env->startSection('page_content'); ?>
    <div class="container-fluid content-inner pb-0">



        <div class="row">
            <div class="col-lg-12 col-md-12 col-12">
                <div class=" pb-4 mb-4 d-md-flex justify-content-between align-items-center">
                    <div class="mb-3 mb-md-0">
                        <h1 class="mb-0 h2 fw-bold">Slots Management</h1>
                    </div>
                </div>
            </div>
        </div>


        <div class="row mb-4">

            <?php $__currentLoopData = $slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6">

                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <span class="badge bg-primary">Slot <?php echo e($slot->id); ?></span>


                                </div>
                                <div>
                                    <h2 class="counter" style="visibility: visible;">$ <?php echo e(number_format($slot->price)); ?>

                                    </h2>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between mt-2">
                                <div>
                                    <span class="fw-bold">Percent: </span>
                                </div>
                                <div>
                                    <span>
                                        <?php $__currentLoopData = explode(',', $slot->percent); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($per); ?>%,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="d-flex justify-content-between mt-2">
                                <div>
                                    <span class="fw-bold">Spillover: </span>
                                </div>
                                <div>
                                    <span>
                                        <?php if($slot->spillover): ?>
                                            <?php $__currentLoopData = explode(',', $slot->spillover); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e($per); ?>%,
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <span class="badge bg-danger">No Spillover bonus </span>
                                        <?php endif; ?>
                                    </span>
                                </div>
                            </div>


                            <div class="mt-2 " >
                                <a href="/admin/slot/<?php echo e($slot->id); ?>" class="btn btn-info btn-xs" style="width: 100%; background-color: <?php echo e($slot->color); ?>" > More About Slot</a>
                            </div>

                        </div>
                    </div>


                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/admin/slot_info.blade.php ENDPATH**/ ?>