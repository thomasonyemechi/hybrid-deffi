

<?php $__env->startSection('page_content'); ?>
    <div class="pt-68 pb-80">

        <div class="tf-container">
            <div class="mt-4 coin-item style-2 gap-8">
                <h5>Convert SHC to USDT</h5>
            </div>

            <div class="pt-6  mt-16">
                <div class="swiper tf-swiper swiper-wrapper-r mt-16 swiper-initialized swiper-horizontal swiper-pointer-events swiper-backface-hidden"
                    data-space-between="16" data-preview="2" data-tablet="2" data-desktop="3">
                    <div class="swiper-wrapper" id="swiper-wrapper-58b5a9a38e046c3c" aria-live="polite"
                        style="transform: translate3d(0px, 0px, 0px);">
                        <div class="swiper-slide">
                            <a href="javascript:;" class="coin-box d-block">
                                <div class="coin-logo">
                                    <img src="<?php echo e(asset('assets/images/coins/02.png')); ?>" alt="img" class="logo">
                                    <div class="title">
                                        <p>SHC Balance</p>
                                        <span> <?php echo e(number_format($spc_balance, 2)); ?> SHC</span>
                                    </div>
                                </div>
                                <div class="blur bg1">
                                </div>
                            </a>
                        </div>
                    </div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                </div>
            </div>








            <form method="post" id="buypmc" action="<?php echo e(route('trade_spc')); ?>"><?php echo csrf_field(); ?>
                <div class="form-group mt-8">
                    <label class="label-ip">
                        <p class="mb-8 text-small"> Amount to Trade </p>
                        <input type="number" name="amount" max="<?php echo e($spc_balance); ?>" value="<?php echo e(old('amount')); ?>">
                    </label>

                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <i class="text-danger "><?php echo e($message); ?> </i>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <button class="mt-20 buypmcbtn">Trade SHC </button>
            </form>





            <div class="mt-20">
                <ul class="menu-tab-v3" role="tablist">
                    <li class="nav-link active" data-bs-toggle="tab" data-bs-target="#cryptocurrency" role="tab"
                        aria-controls="cryptocurrency" aria-selected="true">
                        SHC conversion History
                    </li>
                </ul>
                <div class="tab-content mt-16 mb-16">
                    <div class="tab-pane fade show active" id="cryptocurrency" role="tabpanel">
                        <ul>


                            <?php $__currentLoopData = $trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="mt-16">
                                    <a class="coin-item style-2 gap-12">
                                        <img src="<?php echo e(asset('assets/images/coins/01.png')); ?>" class="img" alt="">
                                        <div class="content">
                                            <div class="title">
                                                <p class="mb-4 text-button text-success "> +
                                                    <?php echo e(number_format($pur->amount)); ?> USDT</p>
                                                <span
                                                    class="text-secondary"><?php echo e(date('j M Y h:i a', strtotime($pur->created_at))); ?>

                                                </span>
                                            </div>
                                            <div class="d-flex align-items-center gap-12">
                                                <span class="coin-btn decrease">-<?php echo e($pur->amount); ?> SHC</span>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if(count($trades) == 0): ?>
                                <li class="mt-16">
                                    <div class="swiper-slide swiper-slide-active mt-12">
                                        <div class="accent-box-v5 bg-menuDark " style="border: 1px solid #fc0">
                                            <div class="mt-12">
                                                <a href="#" class="text-small"> No Items !! </a>
                                                <p class="mt-4">
                                                    There are no items to display on this section, SHC that have been converted to usdt will be displayed here 
                                                    <br>

                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </li>
                            <?php endif; ?>




                        </ul>
                    </div>
                </div>
            </div>


        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/mobile/trade.blade.php ENDPATH**/ ?>