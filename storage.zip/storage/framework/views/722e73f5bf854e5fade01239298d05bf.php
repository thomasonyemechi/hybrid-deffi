<?php $__env->startSection('page_content'); ?>
    <div class="container-fluid content-inner pb-0">
        <div class="row mb-4">
            <div class="col-lg-4">

                <?php if(pendingWithAlert() > 0): ?>
                    <div class="mb-3">

                        <div class="card bg-soft-primary">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center">
                                    <div class="bg-soft-primary rounded p-3">
                                   <b>p</b>

                                    </div>
                                    <div class="text-end">
                                        <h2 class="counter" style="visibility: visible;"><?php echo e(pendingWithAlert()); ?></h2>
                                        Pending Withdrawals
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="card card-block card-stretch custom-scroll">
                    <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-3">
                        <div class="caption">
                            <h6 class="font-weight-bold text-sm mb-2">Credit User</h6>
                        </div>
                    </div>
                    <div class="card-body">
                        <form action="/admin/credit" method="post">

                            <?php echo csrf_field(); ?>

                            <div class="alert alert-warning">
                                Credit user's wallet with Hybrid Coin or USDT
                            </div>


                            <div class="form-group">
                                <label for="">Credit Type <span class="text-danger">*</span></label>
                                <select name="type" class="form-control" id="">
                                    <option value="normal">Normal Credit </option>
                                </select>
                                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <i class="text-danger fw-bold "><?php echo e($message); ?> </i>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="alert type_dis alert-info mt-2">

                                </div>


                            </div>



                            <div class="form-group">
                                <label for="">Currency <span class="text-danger">*</span></label>
                                <select name="currency" class="form-control" id="">
                                    <option value="hbc"> Hybrid Coin (HBC) </option>
                                    <option value="usdt"> USDT (USDT) </option>
                                </select>
                                <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <i class="text-danger fw-bold "><?php echo e($message); ?> </i>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="form-group">
                                <label for="">Wallet Address <span class="text-danger">*</span> </label>
                                <input type="text" name="wallet_address" class="form-control"
                                    value="<?php echo e(old('wallet_address')); ?>" placeholder="Enter user's wallet address">
                                <?php $__errorArgs = ['wallet_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <i class="text-danger fw-bold "><?php echo e($message); ?> </i>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="form-group">
                                <label for="">Amount <span class="text-danger">*</span></label>
                                <input type="number" name="amount" step="any" class="form-control"
                                    value="<?php echo e(old('amount')); ?>" placeholder="Amount to send ">
                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <i class="text-danger fw-bold "><?php echo e($message); ?> </i>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>



                            <div class="form-group">
                                <div class="d-flex justify-content-between ">
                                    <label for="">Remark</label>
                                    <label for="" class="badge text-end mb-1 bg-warning fill_me">USDT
                                        DEPOSIT</label>
                                </div>
                                <input type="text" name="remark" class="form-control" value="<?php echo e(old('remark')); ?>"
                                    placeholder="Describe this transaction">
                                <?php $__errorArgs = ['remark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <i class="text-danger fw-bold "><?php echo e($message); ?> </i>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="form-group">
                                <label for="">Confirm Access Pin</label>
                                <input type="password" name="access_pin" class="form-control"
                                    value="<?php echo e(old('access_pin')); ?>" placeholder="******">
                                <?php $__errorArgs = ['access_pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <i class="text-danger fw-bold "><?php echo e($message); ?> </i>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>



                            <div class="mt-2 d-flex justify-content-end ">
                                <button class="btn btn-sm  btn-primary">Credit User</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="col-lg-12">
                    <div class="card card-block card-stretch custom-scroll">
                        <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-3">
                            <div class="caption">
                                <h4 class="font-weight-bold mb-2">Credit History</h4>
                            </div>

                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table mb-0 text-nowrap">
                                    <thead class="table-light">
                                        <tr>
                                            <th scope="col" class="border-0">Amount</th>
                                            <th scope="col" class="border-0">Wallet Address</th>
                                            <th scope="col" class="border-0">Remark</th>
                                            <th scope="col" class="border-0">By</th>
                                            <th scope="col" class="border-0 text-end">Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="align-middle text-success border-top-0">
                                                    <?php echo e(number_format($credit->amount, 2)); ?>

                                                    <?php echo e($credit->currency); ?>

                                                </td>
                                                <td class="align-middle border-top-0">
                                                    <?php echo e($credit->user->wallet ?? $credit->user->username); ?>

                                                </td>
                                                <td class="align-middle border-top-0">
                                                    <?php echo e($credit->remark); ?>

                                                </td>
                                                <td class="align-middle border-top-0">
                                                    <?php echo e($credit->admin->username); ?>

                                                </td>
                                                <td class="align-middle border-top-0 text-end">
                                                    <?php echo e($credit->created_at); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-flex justify-content-end mt-3 ">
                                <?php echo e($credits->links('pagination::bootstrap-4')); ?>

                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>


    <?php $__env->startPush('scripts'); ?>
        <script>
            $(function() {
                $('body').on('click', '.fill_me', function() {
                    text = $(this).html();
                    $('input[name="remark"]').val(text);
                })

                function doType() {
                    val = $('select[name="type"]').val();
                    dis = $('.type_dis');
                    if (val == 'normal') {
                        dis.html(
                            `User will be credit in default currency and uplines will receive the referral bonus`)
                    } else {
                        dis.html(`User wil be credited in selected curency and no referral payment will be made`);
                    }
                }


                $('select[name="type"]').on('change', function() {
                    doType()
                })

                doType();

            })
        </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/admin/credit_users.blade.php ENDPATH**/ ?>