<div id="depositModalToZone" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="depositModalToZone"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable  modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tranfer To HybridZone Wallet</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">


                <div>
                    <form method="post" action="<?php echo e(route('transfer_tozone')); ?>"><?php echo csrf_field(); ?>
                        <div class="d-1">
                            <div class="alert alert-info">
                                USDT will be transfered to your Hybrid Zone wallet, where you will be able to use
                                funds to activate hyrid zones
                            </div>



                            <div class="card shining-card mb-3">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div class="d-flex align-items-center gap-2">
                                            <img src="<?php echo e(asset('assets/images/coins/01.png')); ?>"
                                                class="img-fluid avatar avatar-30 avatar-rounded" style="width: 30px">
                                            <span class="fs-6 fw-bold me-2" style="line-height: 20px">USDT balance
                                                <br>
                                                <span style="font-weight: lighter">
                                                    <?php echo e(number_format($usdt_balance, 2)); ?>

                                                    <small>USDT</small> </span></span>
                                        </div>
                                    </div>
                                </div>
                            </div>



                            <div class="form-group">
                                <label for="amount">Amount <span class="text-danger">*</span> </label>
                                <input type="number" class="form-control amount" name="amount" min="6"
                                    placeholder="Enter Amount" required>
                                <i class="text-danger amt_error "></i>

                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <i class="text-danger  "><?php echo e($message); ?> </i>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group l2 ">
                                <label for="text">Access Pin</label>
                                <input type="password" name="access_pin" autocomplete="new-password"
                                    class="form-control" placeholder="Enter yout six digit pin">
                                <small class="text-info text-sm">
                                    Enter your access pin to completed transaction
                                </small>
                            </div>


                            <div class="d-flex justify-content-end ">
                                <button type="submit" class="btn btn-primary rounded">Transfer to HybridZone
                                    Wallet</button>
                            </div>
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/users/transfer_to_zone_modal.blade.php ENDPATH**/ ?>