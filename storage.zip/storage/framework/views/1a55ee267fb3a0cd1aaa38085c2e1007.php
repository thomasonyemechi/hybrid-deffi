

<?php $__env->startSection('page_content'); ?>
    <?php
        $vr = $errors->any() ? 1 : 0;
        $er = session('success') || $errors->any() ? 1 : 0;
        $sr = session('success') ? 1 : 0;
    ?>
    <div class="container-fluid content-inner pb-0">
        <div class="row pt-2">
            <div class="col-lg-12">
                <div class="alert alert-solid alert-warning">
                    Funds will be lost if sent from any wallet different from the wallet address you launched with
                    <br>
                    <span class="badge bg-success"> <?php echo e(auth()->user()->wallet); ?> </span>
                    <br>
                    Recommended wallet is Trust Wallet
                </div>
                <div class="alert alert-solid alert-primary shadow d-flex align-items-center" role="alert">
                    <div>
                        <p>

                            To fund your Hybrid Wallet, kindly send a minimum of 400 TRX (TRC20) to the address below. In
                            less
                            than 12 hours, when your deposit is confirmed, our system will automatically convert TRX
                            to
                            USDT into your Hybrid Wallet.


                        </p>


                        <div class="wallet_area">

                            <div class="wallet_loader mb-3">
                                <span class="spinner-border spinner-border-sm" aria-hidden="true"></span> <i
                                    class="">Loading Deposit Wallet Address ... </i>
                            </div>
                            <div class="wallet_copy">

                            </div>
                        </div>


                        <p>

                            The above deposit address is been changed from time to time to ensure an efficient
                            infrastructure and fund security for users. Please always check before sending TRX.</p>

                    </div>
                </div>

                <div class="card card-block card-stretch custom-scroll">
                    <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-3">
                        <div class="caption">
                            <h4 class="font-weight-bold mb-2">Your Deposits</h4>
                        </div>
                        
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table data-table mb-0">
                                <thead>
                                    <tr>
                                        <th scope="col">Amount</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Remark</th>
                                        <th scope="col">Timestamp</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="white-space-no-wrap">
                                            <td class="pe-2"> <?php echo depositAmount($dep->amount); ?> </td>
                                            <td>
                                                <div class="badge bg-success">
                                                    Successful
                                                </div>
                                            </td>
                                            <td><?php echo e($dep->remark); ?> </td>
                                            <td> <?php echo e($dep->created_at); ?> </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        


    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        const input_field = document.getElementById('input_field')

        function yourFunction() {
            input_field.select(); // select the input field
            input_field.setSelectionRange(0, 99999); // For mobile devices
            navigator.clipboard.writeText(input_field.value)

        }




        function getStorage(key) {

            expire_time = localStorage.getItem('dep_wallet_expire');
            current_time = `<?php echo e(time()); ?>`

            console.log(current_time - expire_time);
            if (current_time > expire_time) {
                // expire time has reahed 
                //  get new key
                return walletnew();
            } else {
                // use old key
                var value = localStorage.getItem(key);
                return value;
            }
        }


        function walletnew() {

            new_wallet = '';
            // load wallet
            $.ajax({
                method: 'get',
                url: `/validate_wallet`
            }).done(function(res) {
                new_wallet = res.new_wallet
                console.log(res);
                setStorage('dep_wallet', res.new_wallet);
                loadWallet()
            }).fail(function(res) {
                console.log(res);
            })
            return new_wallet;
        }


        function setStorage(key, value) {
            try {
                localStorage.setItem(key, value);
                localStorage.setItem('dep_wallet_expire', `<?php echo e(time() + 86400); ?>`);
            } catch (e) {
                console.log('setStorage: Error setting key [' + key + '] in localStorage: ' + JSON.stringify(e));
                return false;
            }
            return true;
        }




        function loadWallet() {
            wallet = getStorage('dep_wallet')
            loadString(wallet);
        }


        function loadString(old_wallet) {
            wallet_area = $('.wallet_area');

            wallet_loader = $(wallet_area).find('.wallet_loader');
            wallet_loader.hide();

            wallet_copy = $(wallet_area).find('.wallet_copy');
            wallet_copy.html(`
                    <span class="badge mb-2 bg-danger"> ${old_wallet} </span>
                    <div class="d-flex mb-3 justify-content-lg-start">
                        <input type="text" id="input_field" readonly
                            class="form-control shadow text-danger bg-light form-control-sm fw-bold me-2"
                            style="border: 2px solid red;" value="${old_wallet}">
                        <button class="btn bg-light fw-bold text-danger shadow " onclick="yourFunction()"
                            style="border: 2px solid red;" type="submit">Copy</button>
                    </div>
                `)
        }

        loadWallet();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/users/deposit.blade.php ENDPATH**/ ?>