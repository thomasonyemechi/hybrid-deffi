



<div class="modal fade modalRight" id="depositModalToZone">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="header fixed-top bg-surface d-flex justify-content-center align-items-center">
                <span class="left" data-bs-dismiss="modal" aria-hidden="true"><i class="icon-left-btn"></i></span>
                <h3>Tranfer To HybridZone Wallet</h3>
            </div>
            <div class="overflow-auto pt-45 pb-16">
                <div class="tf-container">
                    <div>
                        <form method="post" action="<?php echo e(route('transfer_tozone')); ?>"><?php echo csrf_field(); ?>
                            <div class="d-1">



                                <div class="swiper tf-swiper swiper-wrapper-r mt-16 swiper-initialized swiper-horizontal swiper-pointer-events swiper-backface-hidden"
                                    data-space-between="16" data-preview="2.8" data-tablet="2.8" data-desktop="3">
                                    <div class="swiper-wrapper" id="swiper-wrapper-58b5a9a38e046c3c" aria-live="polite"
                                        style="transform: translate3d(0px, 0px, 0px);">
                                        <div class="swiper-slide">
                                            <a href="javascript:;" class="coin-box d-block">
                                                <div class="coin-logo">
                                                    <img src="<?php echo e(asset('assets/images/coins/01.png')); ?>" alt="img"
                                                        class="logo">
                                                    <div class="title">
                                                        <p>USDT Balance</p>
                                                        <span><?php echo e(number_format($usdt_balance, 2)); ?> usdt</span>
                                                    </div>
                                                </div>
                                                <div class="blur bg3">
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                                </div>






                                <div class="swiper-slide swiper-slide-active mt-12 mb-3">
                                    <div class="accent-box-v5 bg-menuDark " style="border-color: #fc0">
                                        <span class="icon-box bg-icon1"><i class="fw-bold"
                                                style="font-weight: 600 !important; color: white;">!!</i></span>
                                        <div class="mt-12">
                                            <a href="#" class="text-small">Before You Trasnfer !!</a>
                                            <p class="mt-4">
                                                USDT will be transfered to your Hybrid Zone wallet, where you will be
                                                able to use funds to activate hyrid zones
                                            </p>

                                        </div>
                                    </div>
                                </div>



                                <div class="form-group mt-8">
                                    <label class="label-ip">
                                        <p class="mb-8 text-small"> Amount</p>
                                        <input class="text-white amount" type="number" placeholder="Enter Amount"
                                            required="required" name="amount">
                                        <i class="text-danger amt_error "></i>
                                    </label>

                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <i class="text-danger  "><?php echo e($message); ?> </i>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                </div>


                                <div class="form-group l2 mt-8">

                                    <label class="label-ip">
                                        <p class="mb-8 text-small"> Access Pin </p>
                                        <input class="" type="password" placeholder="Enter yout six digit pin "
                                            autocomplete="new-password" name="access_pin">
                                    </label>
                                </div>


                                <button type="submit" class="mt-20  ">Tranfer To HybridZone Wallet</button>
                            </div>


                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/mobile/transfer_to_zone_modal.blade.php ENDPATH**/ ?>