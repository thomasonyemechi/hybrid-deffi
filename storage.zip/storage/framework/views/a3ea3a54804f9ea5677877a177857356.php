

<?php $__env->startSection('page_content'); ?>
    <div class="pt-68 pb-80">

        <div class="tf-container">
            <div class="mt-4 coin-item style-2 gap-8">
                <h5>Withdrawal USDT</h5>
            </div>

            <div class="pt-6  mt-16">
                <div class="swiper tf-swiper swiper-wrapper-r mt-16 swiper-initialized swiper-horizontal swiper-pointer-events swiper-backface-hidden"
                    data-space-between="16" data-preview="2" data-tablet="2" data-desktop="3">
                    <div class="swiper-wrapper" id="swiper-wrapper-58b5a9a38e046c3c" aria-live="polite"
                        style="transform: translate3d(0px, 0px, 0px);">
                        <div class="swiper-slide">
                            <a href="javascript:;" class="coin-box d-block">
                                <div class="coin-logo">
                                    <img src="<?php echo e(asset('assets/images/coins/01.png')); ?>" alt="img" class="logo">
                                    <div class="title">
                                        <p>USDT Balance</p>
                                        <span><?php echo e(number_format($usdt_balance, 2)); ?> USDT</span>
                                    </div>
                                </div>
                                <div class="blur bg2">
                                </div>
                            </a>
                        </div>
                    </div>
                    <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span>
                </div>
            </div>








            <form method="post" action="/withdrawal"><?php echo csrf_field(); ?>
                <div class="form-group mt-8">
                    <label class="label-ip">
                        <p class="mb-8 text-small"> Amount In USDT </p>
                        <input type="number" name="amount" min="10" placeholder="Minimum: 10 USDT"
                            max="<?php echo e($usdt_balance); ?>">

                    </label>

                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <i class="text-danger "><?php echo e($message); ?> </i>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <button class="mt-20 buypmcbtn">Withdraw USDT </button>
            </form>





            <div class="mt-20">
                <ul class="menu-tab-v3" role="tablist">
                    <li class="nav-link active" data-bs-toggle="tab" data-bs-target="#cryptocurrency" role="tab"
                        aria-controls="cryptocurrency" aria-selected="true">
                        USDT Withdrawal History
                    </li>
                </ul>
                <div class="tab-content mt-16 mb-16">
                    <div class="tab-pane fade show active" id="cryptocurrency" role="tabpanel">
                        <ul>

                            <?php $__currentLoopData = $withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $with): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="mt-16">
                                    <a class="coin-item style-2 gap-12">
                                        <img src="<?php echo e(asset('mobile/images/coin/coin-2.jpg')); ?>" alt="img"
                                            class="img">
                                        <div class="content">
                                            <div class="title">

                                                <?php if($with->status == 'approved'): ?>
                                                    <p class="mb-4 text-button text-danger "> -
                                                        <?php echo e(number_format($with->amount)); ?> USDT</p>
                                                <?php else: ?>
                                                    <p class="mb-4 text-button  ">
                                                        <?php echo e(number_format($with->amount)); ?> USDT</p>
                                                <?php endif; ?>

                                                <span
                                                    class="text-secondary"><?php echo e(date('j M Y h:i a', strtotime($with->created_at))); ?>

                                                </span>
                                            </div>
                                            <div class="d-flex align-items-center gap-12">
                                                <?php echo depositStatus($with->status); ?>

                                            </div>
                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if(count($withdrawals) == 0): ?>
                                <li class="mt-16">
                                    <div class="swiper-slide swiper-slide-active mt-12">
                                        <div class="accent-box-v5 bg-menuDark " style="border: 1px solid #fc0">
                                            <div class="mt-12">
                                                <a href="#" class="text-small"> No Items !! </a>
                                                <p class="mt-4">
                                                    There are no items to display on this section, USDT withdrawals will be
                                                    displayed here
                                                    <br>
                                                </p>

                                            </div>
                                        </div>
                                    </div>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>


        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/mobile/withdrwal.blade.php ENDPATH**/ ?>