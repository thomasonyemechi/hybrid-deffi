

<?php $__env->startSection('page_content'); ?>
    <div class="container-fluid content-inner pb-0">
        <div class="row mb-4">
            <div class="col-lg-12">

                <marquee behavior="" direction="" class="mb-3">
                    <?php $__currentLoopData = $announcement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ann): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($ann->announcement); ?> <b></b>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </marquee>



                <div class="row align-items-center">
                    
                    <div class="col-xl-4">
                        <div class="d-grid grid-3-auto gap-card">
                            <div class="dropdown">
                                <a href="/deposit" class="btn btn-primary w-100">
                                    Deposit
                                </a>
                            </div>
                            <div class="dropdown">
                                <a href="/convert" class="btn btn-primary w-100" type="button">
                                    Buy Coin
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row pt-2">
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card shining-card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-center">
                                            <div class="">
                                                <span class="fs-1 text-white fw-bold me-2"
                                                    style="font-size: 20px">$<?php echo e(number_format($total, 2)); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card shining-card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center gap-2">
                                                <img src="<?php echo e(asset('assets/images/coins/00.png')); ?>"
                                                    class="img-fluid avatar avatar-30 avatar-rounded" style="width: 30px">
                                                <span class="fs-6 fw-bold me-2" style="line-height: 20px"><a href="/convert"
                                                        class="text-white">Hybridcoin</a> <br>
                                                    <span
                                                        style="font-weight: lighter">$<?php echo e(number_format(1 / $rate, 4)); ?></span></span>
                                            </div>
                                            <div class="d-flex align-items-center gap-2">
                                                <span class="fs-6 fw-bold me-2"
                                                    style="line-height: 20px"><?php echo e(number_format($pc_balance, 4)); ?> HBC <br>
                                                    <span style="font-weight: lighter">$
                                                        <?php echo e(number_format($pc_total, 4)); ?></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card shining-card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center gap-2">
                                                <img src="<?php echo e(asset('assets/images/coins/01.png')); ?>"
                                                    class="img-fluid avatar avatar-30 avatar-rounded" style="width: 30px">
                                                <span class="fs-6 fw-bold me-2" style="line-height: 20px">USDT <br>
                                                    <span
                                                        style="font-weight: lighter">$<?php echo e(number_format(1, 2)); ?></span></span>
                                            </div>
                                            <div class="d-flex align-items-center gap-2">
                                                <span class="fs-6 fw-bold me-2" style="line-height: 20px">
                                                    <?php echo e(number_format(usdtBalance($user_id), 2)); ?> USDT <br>
                                                    <span
                                                        style="font-weight: lighter">$<?php echo e(number_format($usdt_balance, 2)); ?></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card shining-card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center gap-2">
                                                <img src="<?php echo e(asset('assets/images/coins/02.png')); ?>"
                                                    class="img-fluid avatar avatar-30 avatar-rounded" style="width: 30px">
                                                <span class="fs-6 fw-bold me-2" style="line-height: 20px">Commission <br>
                                                    <span
                                                        style="font-weight: lighter">$<?php echo e(number_format(1, 2)); ?></span></span>
                                            </div>
                                            <div class="d-flex align-items-center gap-2">
                                                <span class="fs-6 fw-bold me-2"
                                                    style="line-height: 20px"><?php echo e(number_format($spc_balance, 2)); ?> SHC <br>
                                                    <span
                                                        style="font-weight: lighter">$<?php echo e(number_format($spc_balance, 2)); ?></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        
                    </div>
                    <div class="col-lg-12">




                        <div class="card card-block card-stretch custom-scroll">
                            <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-3">
                                <div class="caption">
                                    <h4 class="font-weight-bold mb-2">Recent Transactions</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table data-table mb-0">
                                        <thead>
                                            <tr>
                                                <th scope="col">Amount</th>
                                                <th scope="col">Description</th>
                                                <th scope="col">Timestamp</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(number_format($trno->amount, 2)); ?> <?php echo e($trno->currency); ?> </td>
                                                    <td> <?php echo e($trno->remark); ?> </td>
                                                    <td> <?php echo e($trno->created_at); ?> </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div>
                                    <a href="/how-to-earn" class="btn btn-primary mt-2 py-1">HOW TO EARN IN Hybrid
                                        PROJECT</a>
                                </div>
                            </div>
                        </div>



                        <div class="accordion mb-4" id="accordionExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        HOW DO I ACCESS MY HYBRID WALLET?
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <ul>
                                            <li>Visit <a href=" www.hybriddefi.com"> www.hybriddefi.com </a> on your
                                                decentralized wallet browser</li>
                                            <li>Click Gain Access</li>
                                            <li>Input your wallet address and access pin and click ACCESS.</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading2">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse2" aria-expanded="true" aria-controls="collapse2">
                                        HOW TO BUY HYBRID COIN?
                                    </button>
                                </h2>
                                <div id="collapse2" class="accordion-collapse collapse " aria-labelledby="heading2"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <ul>
                                            <li>Access your hybrid dashboard and click on deposit to fund your hybrid
                                                wallet. Follow the guidelines on the deposit page to fund your Hybrid wallet
                                                with USDT using TRX.
                                            </li>
                                            <li>When your deposit is confirmed, click buy coin at the dashboard</li>
                                            <li>Input the amount in USDT you want to purchase and click on buy. </li>
                                            <li>Your USDT balance will be debited and your hybrid balance credited
                                                immediately</li>
                                            <li></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading3">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse3" aria-expanded="true" aria-controls="collapse3">
                                        HOW TO WITHDRAW USDT FROM MY HYBRID WALLET?
                                    </button>
                                </h2>
                                <div id="collapse3" class="accordion-collapse collapse " aria-labelledby="heading3"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        To withdraw USDT from your hybrid wallet:

                                        <ul>
                                            <li>Click the menu button
                                            </li>
                                            <li>Click Withdrawal</li>
                                            <li>Input the amount of USDT you want to withdraw</li>
                                            <li>The USDT will be automatically converted to TRX and sent to your personal
                                                TRX wallet</li>
                                            <li></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>


                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading4">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse4" aria-expanded="true" aria-controls="collapse4">
                                        HOW TO WITHDRAW MY AFFILIATE COMMISSION?

                                    </button>
                                </h2>
                                <div id="collapse4" class="accordion-collapse collapse " aria-labelledby="heading4"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        Your affiliate commission is sent to your hybrid wallet as SHC. SHC can be converted
                                        to USDT or Hybridcoin
                                        <ul>
                                            <li>Click the menu button
                                            </li>
                                            <li>Click Convert</li>
                                            <li>Input the amount of SHC you want to convert to USDT and click trade.
                                            </li>
                                            <li>The SHC will be immediately converted to USDT. You can now withdraw the USDT
                                                to your external wallet address</li>

                                        </ul>
                                    </div>
                                </div>
                            </div>



                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading5">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapse5" aria-expanded="true" aria-controls="collapse5">
                                        HOW DO GET MY LINK TO INVITE OTHERS?

                                    </button>
                                </h2>
                                <div id="collapse5" class="accordion-collapse collapse" aria-labelledby="heading5"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        To help the hybrid community grow fast, when participants purchase hybrid coin, 10%
                                        of the USDT is distributed as referral commission to three generations. 6%, 2% and
                                        2% respectively
                                        <ul>
                                            <li>Click the menu button
                                            </li>
                                            <li>Click Invite Others</li>
                                            <li>Copy your invite link and share with family and friends</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                
            </div>
        </div>

    </div>






<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
    <script>
        function myFunction() {
            // Get the text field
            var copyText = document.getElementById("wallet_address");

            // Select the text field
            copyText.select();
            copyText.setSelectionRange(0, 99999); // For mobile devices

            // Copy the text inside the text field
            navigator.clipboard.writeText(copyText.value);

            // Alert the copied text
            alert("Referral ID has been copied");
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/users/index.blade.php ENDPATH**/ ?>