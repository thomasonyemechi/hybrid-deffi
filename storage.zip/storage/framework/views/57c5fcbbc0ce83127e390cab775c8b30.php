

<?php $__env->startSection('page_content'); ?>
    <div class="container-fluid content-inner pb-0">
        <div class="row mb-4">
            <div class="col-lg-12">
            </div>
        </div>
        <div class="row pt-2">
            <div class="col-lg-8">
                <div class="row">
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
 
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prime-coin\resources\views/admin/index.blade.php ENDPATH**/ ?>