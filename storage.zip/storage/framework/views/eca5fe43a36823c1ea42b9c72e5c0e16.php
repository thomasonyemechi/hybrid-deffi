

<?php $__env->startSection('page_content'); ?>
    <div class="container-fluid content-inner pb-0">
        <div class="row mb-4">
            <div class="col-lg-12">
                <div class="row align-items-center">
                    
                    <div class="col-xl-4">
                        <div class="d-grid grid-3-auto gap-card">
                            <div class="dropdown">
                                <a href="/deposit" class="btn btn-primary w-100">
                                    Deposit
                                </a>
                            </div>
                            <div class="dropdown">
                                <a href="/convert" class="btn btn-primary w-100" type="button">
                                    Buy Coin
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row pt-2">
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card shining-card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-center">
                                            <div class="">
                                                <span class="fs-1 text-white fw-bold me-2"
                                                    style="font-size: 20px">$<?php echo e(number_format($total, 2)); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="card shining-card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center gap-2">
                                                <img src="<?php echo e(asset('assets/images/coins/00.png')); ?>"
                                                    class="img-fluid avatar avatar-30 avatar-rounded" style="width: 30px">
                                                <span class="fs-6 fw-bold me-2" style="line-height: 20px"><a href="/convert" class="text-white"  >Primecoin</a> <br>
                                                    <span
                                                        style="font-weight: lighter">$<?php echo e(number_format(1 / $rate, 2)); ?></span></span>
                                            </div>
                                            <div class="d-flex align-items-center gap-2">
                                                <span class="fs-6 fw-bold me-2"
                                                    style="line-height: 20px"><?php echo e(number_format($pc_balance, 2)); ?> PMC <br>
                                                    <span style="font-weight: lighter">$
                                                        <?php echo e(number_format($pc_total, 2)); ?></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card shining-card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center gap-2">
                                                <img src="<?php echo e(asset('assets/images/coins/01.png')); ?>"
                                                    class="img-fluid avatar avatar-30 avatar-rounded" style="width: 30px">
                                                <span class="fs-6 fw-bold me-2" style="line-height: 20px">USDT <br>
                                                    <span
                                                        style="font-weight: lighter">$<?php echo e(number_format(1, 2)); ?></span></span>
                                            </div>
                                            <div class="d-flex align-items-center gap-2">
                                                <span class="fs-6 fw-bold me-2" style="line-height: 20px">
                                                    <?php echo e(number_format(usdtBalance($user_id), 2)); ?> USDT <br>
                                                    <span
                                                        style="font-weight: lighter">$<?php echo e(number_format($usdt_balance, 2)); ?></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="card shining-card">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div class="d-flex align-items-center gap-2">
                                                <img src="<?php echo e(asset('assets/images/coins/02.png')); ?>"
                                                    class="img-fluid avatar avatar-30 avatar-rounded" style="width: 30px">
                                                <span class="fs-6 fw-bold me-2" style="line-height: 20px">Airdrop <br>
                                                    <span
                                                        style="font-weight: lighter">$<?php echo e(number_format(1, 2)); ?></span></span>
                                            </div>
                                            <div class="d-flex align-items-center gap-2">
                                                <span class="fs-6 fw-bold me-2"
                                                    style="line-height: 20px"><?php echo e(number_format($spc_balance, 2)); ?> SPC <br>
                                                    <span
                                                        style="font-weight: lighter">$<?php echo e(number_format($spc_balance, 2)); ?></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        
                    </div>
                    <div class="col-lg-12">
            
                        <div class="card card-block card-stretch custom-scroll">
                            <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-3">
                                <div class="caption">
                                    <h4 class="font-weight-bold mb-2">Recent Transactions</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table data-table mb-0">
                                        <thead>
                                            <tr>
                                                <th scope="col">Amount</th>
                                                <th scope="col">Description</th>
                                                <th scope="col">Timestamp</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(number_format($trno->amount, 2)); ?> <?php echo e($trno->currency); ?> </td>
                                                    <td> <?php echo e($trno->remark); ?> </td>
                                                    <td> <?php echo e($trno->created_at); ?> </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div>
                                    <a href="/how-to-earn"  class="btn btn-primary py-1" >HOW TO EARN IN PRIME PROJECT</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
    <script>
        function myFunction() {
            // Get the text field
            var copyText = document.getElementById("wallet_address");

            // Select the text field
            copyText.select();
            copyText.setSelectionRange(0, 99999); // For mobile devices

            // Copy the text inside the text field
            navigator.clipboard.writeText(copyText.value);

            // Alert the copied text
            alert("Referral ID has been copied");
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\prime-coin\resources\views/users/index.blade.php ENDPATH**/ ?>