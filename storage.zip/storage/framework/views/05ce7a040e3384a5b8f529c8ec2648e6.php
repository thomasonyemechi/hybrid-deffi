

<?php $__env->startSection('page_content'); ?>
    <div class="container-fluid content-inner pb-0">





        <div class="row">
            <div class="col-lg-12">
                <h4 class="font-weight-bold mb-3">Recent Transaction</h4>

                <div class="table-responsive shadow p-1 rounded-3">
                    <table class="table data-table mb-0">
                        <thead>
                            <tr>
                                <th scope="col">Amount</th>
                                <th scope="col">Description</th>
                                <th scope="col">Slot</th>
                                <th scope="col">Timestamp</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td>

                                        <img src="<?php echo e($trno->currency == 'usdt' ? '../../assets/images/coins/01.png' : '../../assets/images/coins/00.png'); ?>"
                                            class="img-fluid avatar avatar-30 avatar-rounded" alt="">
                                        <span class="fw-bold">
                                            <?php if($trno->amount < 0): ?>
                                                <span class="text-danger">
                                                    <svg width="10" height="8" viewBox="0 0 8 5" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M4 4.5L0.535898 0L7.4641 0L4 4.5Z" fill="#FF2E2E">
                                                        </path>
                                                    </svg>
                                                    <?php echo e(number_format(abs($trno->amount), 2)); ?>

                                                    <?php echo e($trno->currency); ?>

                                                </span>
                                            <?php else: ?>
                                                <span class="text-success">
                                                    <svg width="10" height="8" viewBox="0 0 8 5" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M4 0.5L7.4641 5H0.535898L4 0.5Z" fill="#00EC42">
                                                        </path>
                                                    </svg>
                                                    <?php echo e(number_format($trno->amount, 2)); ?>

                                                    <?php echo e($trno->currency); ?>


                                                </span>
                                            <?php endif; ?>
                                        </span>
                                    </td>

                                    <td> <?php echo e($trno->remark); ?> </td>
                                    <td>
                                        <?php if($trno->slot_ref > 0): ?>
                                            <div class="badge" style="background-color: <?php echo e($trno->slot->color); ?> " >
                                                slot <?php echo e($trno->slot_ref); ?>

                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td> <?php echo e(formatDate($trno->created_at)); ?> </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-2 d-flex  justify-content-end ">
                    <?php echo e($transactions->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/users/zone_transactions.blade.php ENDPATH**/ ?>