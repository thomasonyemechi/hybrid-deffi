
<?php $__env->startSection('page_content'); ?>
    <div class="container-fluid content-inner pb-0">



        <div class="row">
            <div class="col-lg-12 col-md-12 col-12">
                <div class=" pb-4 mb-4 d-md-flex justify-content-between align-items-center">
                    <div class="mb-3 mb-md-0">
                        <h1 class="mb-0 h2 fw-bold">Zone Transactions</h1>
                    </div>
                </div>
            </div>
        </div>


        <div class="row mb-4">






            <div class="row">
                <div class="col-md-12">
                    <div class="card card-block card-stretch custom-scroll">
                        <div class="card-body p-0">
                            <div class="table-responsive">



                                <table class="table data-table mb-0">
                                    <thead>
                                        <tr>
                                            <th scope="col">Wallet</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Remark</th>
                                            <th class="text-end" scope="col">Timestamp</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $slot_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <span class="title fw-bold">
                                                        <?php if(isset($trno->user->wallet)): ?>
                                                            <?php echo e(substr($trno->user->wallet, 0, 6) . '...' . substr($trno->user->wallet, -6)); ?>

                                                        <?php else: ?>
                                                            <?php echo e('admin'); ?>

                                                        <?php endif; ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if($trno->amount < 0): ?>
                                                        <span class="text-danger">
                                                            <svg width="10" height="8" viewBox="0 0 8 5"
                                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M4 4.5L0.535898 0L7.4641 0L4 4.5Z" fill="#FF2E2E">
                                                                </path>
                                                            </svg>
                                                            <?php echo e(number_format(abs($trno->amount), 2)); ?>

                                                            <?php echo e($trno->currency); ?>

                                                        </span>
                                                    <?php else: ?>
                                                        <span class="text-success">
                                                            <svg width="10" height="8" viewBox="0 0 8 5"
                                                                fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M4 0.5L7.4641 5H0.535898L4 0.5Z" fill="#00EC42">
                                                                </path>
                                                            </svg>
                                                            <?php echo e(number_format($trno->amount, 2)); ?> <?php echo e($trno->currency); ?>


                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td> <?php echo e($trno->remark); ?> </td>
                                                <td class="text-end"> <?php echo e($trno->created_at); ?> </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>


                    <div class="d-flex justify-content-lg-end " >
                        <?php echo e($slot_transactions->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>






<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.admin02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/admin/zone_transactions.blade.php ENDPATH**/ ?>