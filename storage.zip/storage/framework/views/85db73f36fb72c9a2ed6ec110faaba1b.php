<footer>
            <div class="footer-area-three">
                <div class="container">
              
                    
                    <div class="footer-bottom-three">
                        <div class="row align-items-center">
                            <div class="col-lg-8">
                                <div class="copyright-text">
                                    <p>Copyright © <?php echo e(date('Y')); ?> <?php echo e(env('APP_NAME')); ?> All rights reserved.</p>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="footer-menu">
                                    <ul class="list-wrap">
                                        <li><a href="#">Terms & Conditions</a></li>
                                        <li><a href="#">Refund Policy</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer><?php /**PATH C:\xampp\htdocs\prime-coin\resources\views/layout/inc/footer.blade.php ENDPATH**/ ?>