

<?php $__env->startSection('page_content'); ?>
    <style>
        .icon-book:before {
            content: "\e913";
            color: #fc0;
        }
    </style>



    <div class="pt-68 pb-80">

        <div class="tf-container">










            <div class="tf-container">
                <div class="mt-4 coin-item style-2 gap-8">
                    <img src="<?php echo e(asset('assets/images/coins/00.png')); ?>" alt="img" class="img">
                    <h5>Buy Hybrid Coin</h5>
                </div>


                    <form method="post" id="buypmc" action="<?php echo e(route('buy_hybridcoin')); ?>"><?php echo csrf_field(); ?>

                        <div class="mt-16 group-ip-select">
                            <input type="number" name="usdt_amount" <?php echo e($price > 0 ? 'min=10' : 'min=50'); ?> max="<?php echo e($usdt_balance); ?>"
                                name="usdt" id="usdt" value="<?php echo e(old('wallet')); ?>">
        
        
                            <div class="select-wrapper">
                                <select class="tf-select">
                                    <option value="">USDT</option>
                                </select>
                            </div>
                            <p class="mt-8">10 - 10,0000 USDT</p>
        
                            <?php $__errorArgs = ['wallet'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <i class="text-danger "><?php echo e($message); ?> </i>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
        
                        </div>
        
        
                        <div class="mt-8 group-ip-select">
                            <input type="text" name="pc" id="pc" readonly>
                            <div class="select-wrapper">
                                <select class="tf-select">
                                    <option value="">HBC</option>
                                </select>
                            </div>
                        </div>
        
        
        
        
        
        
                        <button type="submit" class="tf-btn lg primary mt-40 buypmcbtn ">Buy</button>

                    </form>





            </div>






        </div>






    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/mobile/buy_coin.blade.php ENDPATH**/ ?>