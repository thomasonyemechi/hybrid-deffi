

<?php $__env->startSection('page_content'); ?>
    <div class="pt-68 pb-80">
        <div class="bg-menuDark tf-container">
            <div class="pt-12 pb-12 mt-4">
                <h5><span class="text-primary">Wallet</span> - <a href="#" class="choose-account" data-bs-toggle="modal"
                        data-bs-target="#accountWallet"><span class="dom-text">Hybrid Coin </span>
                        &nbsp;<i class="icon-select-down"></i></a> </h5>
                <h1 class="mt-16"><a href="#">$<?php echo e(number_format($total, 2)); ?></a></h1>
                <ul class="mt-16 grid-4 m--16">

                    <li>
                        <a href="/deposit" class="tf-list-item d-flex flex-column gap-8 align-items-center">
                            <span class="box-round bg-surface d-flex justify-content-center align-items-center"><i
                                    class="icon icon-bank"></i></span>
                            Deposit
                        </a>
                    </li>
                    <li>
                        <a href="/convert" class="tf-list-item d-flex flex-column gap-8 align-items-center">
                            <span class="box-round bg-surface d-flex justify-content-center align-items-center"><i
                                    class="icon icon-swap"></i></span>
                            Buy Coin
                        </a>
                    </li>
                    <li>
                        <a href="/earnings" class="tf-list-item d-flex flex-column gap-8 align-items-center">
                            <span class="box-round bg-surface d-flex justify-content-center align-items-center"><i
                                    class="icon icon-exchange"></i></span>
                            Earnings
                        </a>
                    </li>
                    <li>
                        <a href="/transfer" class="tf-list-item d-flex flex-column gap-8 align-items-center">
                            <span class="box-round bg-surface d-flex justify-content-center align-items-center"><i
                                    class="icon icon-way"></i></span>
                            Transfer
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        








        <div class="bg-menuDark tf-container">
            <div class="pt-12 pb-12 mt-4">
                <h5>Other Balance</h5>

                <div class="swiper tf-swiper swiper-wrapper-r mt-16 swiper-initialized swiper-horizontal swiper-pointer-events swiper-backface-hidden" data-space-between="16" data-preview="2.2" data-tablet="2.2" data-desktop="3">
                    <div class="swiper-wrapper" id="swiper-wrapper-58b5a9a38e046c3c" aria-live="polite" style="transform: translate3d(0px, 0px, 0px);">
                
                        <div class="swiper-slide">
                            <a href="javascript:;" class="coin-box d-block">
                                <div class="coin-logo">
                                    <img src="<?php echo e(asset('assets/images/coins/00.png')); ?>" alt="img" class="logo">
                                    <div class="title">
                                        <p>Hybrid Coin</p>
                                        <span>HBC</span>
                                    </div>
                                </div>
                                <div class="mt-8 mb-8 coin-chart">
                                    <div id="line-chart-4"></div>
                                </div>
                                <div class="coin-price d-flex justify-content-between">
                                    <span><?php echo e(number_format($pc_balance, 2)); ?> HBC <br> <small  style="font-size: 10px; color: rgb(197, 186, 186)" >$<?php echo e(number_format($pc_total, 4)); ?></small>  </span>
                                    <span class="text-primary d-flex align-items-center gap-2"><i class="icon-select-up"></i> $<?php echo e(number_format(1 / $rate, 2)); ?></span>
                                </div>
                                <div class="blur bg1">
                                </div>
                            </a>
                        </div>
                        <div class="swiper-slide">
                            <a href="javascript:;" class="coin-box d-block">
                                <div class="coin-logo">
                                    <img src="<?php echo e(asset('assets/images/coins/02.png')); ?>" alt="img" class="logo">
                                    <div class="title">
                                        <p>Commision</p>
                                        <span>SHC</span>
                                    </div>
                                </div>
                                <div class="mt-8 mb-8 coin-chart">
                                    <div id="line-chart-5"></div>
                                </div>
                                <div class="coin-price d-flex justify-content-between">
                                    <span> <?php echo e(number_format($spc_balance, 2)); ?> SHC <br> <small  style="font-size: 10px; color: rgb(197, 186, 186)" >$ $<?php echo e(number_format($spc_balance, 2)); ?></small>   </span>
                                    <span class="text-primary d-flex align-items-center gap-2"><i class="icon-select-up"></i>$<?php echo e(number_format(1, 2)); ?></span>
                                </div>
                                <div class="blur bg2">
                                </div>
                            </a>
                        </div> 
                    </div>
                <span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>
               
            </div>
        </div>





        <div class="bg-menuDark tf-container">
            <div class="tf-tab pt-12 mt-4">
                <div class="tab-slide">
                    <ul class="nav nav-tabs wallet-tabs" role="tablist">
                        <li class="item-slide-effect"></li>
                        <li class="nav-item active" role="presentation">
                            <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#history"
                                aria-selected="true" role="tab">Transactions</button>
                        </li>
                        


                    </ul>
                </div>
                <div class="tab-content pt-16 pb-16">
                    <div class="tab-pane fade active show" id="history" role="tabpanel">
                        <ul>


                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             

                                <li class="mt-8" >
                                    <a href="javascript:;" class="coin-item style-1 gap-12 bg-surface">
                                        <img src="<?php echo e($trno->currency == 'usdt' ? '../../assets/images/coins/01.png' : '../../assets/images/coins/00.png'); ?>"
                                        class="img" alt="">
                                        <div class="content">
                                            <div class="title">
                                                <p class="mb-4 text-large <?php echo e(($trno->amount > 0) ? 'text-success' : 'text-danger'); ?> "  ><?php echo e(number_format($trno->amount, 2)); ?> <?php echo e($trno->currency); ?></p>
                                                <span class="text-secondary"><?php echo e(formatDate($trno->created_at)); ?></span>
                                            </div>
                                            <div class="box-price">
                                                <p class="text-small text-end mb-4"><span class="text-primary">+</span> BTC 0.0056</p>
                                                <p class="text-end"><?php echo e($trno->remark); ?> </p>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                        </ul>
                    </div>
                    <div class="tab-pane fade" id="market" role="tabpanel">
                        <ul>
             
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>



    </div>



    <div class="modal fade action-sheet" id="accountWallet">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <span>Wallet</span>
                    <span class="icon-cancel" data-bs-dismiss="modal"></span>
                </div>
                <ul class="mt-20 pb-16">
                    <li data-bs-dismiss="modal">
                        <div
                            class="d-flex justify-content-between align-items-center gap-8 text-large item-check active dom-value">
                            Hybrid Coin Account <i class="icon icon-check-circle"></i> </div>
                    </li>
                    <li class="mt-4" data-bs-dismiss="modal">
                        <div class="d-flex  justify-content-between gap-8 text-large item-check dom-value">hybrid Zone
                            Account<i class="icon icon-check-circle"></i></div>
                    </li>
                </ul>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.mobile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/mobile/index.blade.php ENDPATH**/ ?>