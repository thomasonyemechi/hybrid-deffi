<?php $__env->startSection('page_content'); ?>
    <div class="container-fluid content-inner pb-0">
        <div class="row mb-4">
            <div class="col-lg-12">

                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between ">
                            <h4 class="card-title text-white">Manage Users</h4>
                            <div class="form-outline">
                                <form action="">
                                    <input type="search" name="user" class="form-control ms-1" style="width: 300px"
                                        placeholder="Search users by wallet, username.." aria-label="Search">
                                </form>
                            </div>
                        </div>

                        <div class="card-body">
                            <?php echo isset($_GET['user'])
                                ? '<p class="mb-2 fw-bold" >Search Result for <b>" ' . $_GET['user'] . ' "</b></p>'
                                : ''; ?>

                            <div class="table-responsive">
                                <table class="table">
                                    <thead class="">
                                        <tr>
                                            <th>Wallet Address</th>
                                            <th>HBC</th>
                                            <th>USDT</th>
                                            <th>SHC</th>
                                            <th>Purchase</th>
                                            <th>Zone <br> Level </th>
                                            <th>Zone <br> Earning </th>
                                            <th>Zone <br> Balance </th>
                                            <th>Reffered By</th>
                                            <th>Last Login</th>
                                            <th>Joined</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if(count($users) == 0): ?>
                                            <tr>
                                                <td colspan="12">
                                                    <div class="alert alert-danger">
                                                        There is no content on this table
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td style="width: 80%; whitespace: wrap; "> <a class=" fw-bold text-white   "  style="width: 80%" href="#">
                                                        <span ><?php echo e($user->wallet); ?> </span> </a> </td>
                                                <td>
                                                    <span class="badge bg-warning">
                                                        <?php echo e(number_format(pcBalance($user->id))); ?> HBC </span>
                                                </td>
                                                <td> <?php echo e(number_format(usdtBalance($user->id))); ?> USDT </td>
                                                <td> <?php echo e(number_format(spcBalance($user->id))); ?> SHC </td>
                                                <td> <?php echo e(number_format(coinTotalPurchase($user->id))); ?> USDT </td>
                                                <td>
                                                    <?php
                                                        $slot = \App\Models\MySlot::with(['slot'])
                                                            ->where(['user_id' => $user->id])
                                                            ->orderby('id', 'desc')
                                                            ->first();

                                                    ?>

                                                    <?php if($slot): ?>
                                                        <span class="badge py-1"
                                                            style=" background-color: <?php echo e($slot->slot->color); ?>; ">Zone
                                                            <?php echo e($slot->slot->id); ?></span>
                                                    <?php else: ?>
                                                        <span class="badge py-1 text-danger ">No Slot</span>
                                                    <?php endif; ?>

                                                </td>
                                                <td>
                                                    <span class="badge bg-success">
                                                        $<?php echo e(number_format(\App\Models\ZEarning::where(['user_id' => $user->id, 'currency' => 'usdt'])->sum('amount'))); ?>

                                                    </span>
                                                </td>

                                                <td>
                                                    <span class="fw-bold">
                                                        $ <?php echo e(number_format($user->zoneUsdtBalance())); ?> </span>
                                                </td>


                                                <td>


                                             
                                                    <?php echo e(($user->sponsor > 0) ? \App\Models\User::find($user->sponsor)->wallet : 'No sponsor'); ?>

                                                </td>
                                                <td> <?php echo e(date('j M, Y', strtotime($user->last_login))); ?> </td>

                                                <td> <?php echo e(date('j M, Y', strtotime($user->created_at))); ?> </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                                <div class="d-flex justify-content-between flex-wrap">
                                    <?php echo e($users->links('pagination::bootstrap-4')); ?>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/admin/users.blade.php ENDPATH**/ ?>