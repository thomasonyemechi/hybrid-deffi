

<?php $__env->startSection('page_content'); ?>
    <div class="container-fluid content-inner pb-0">
        <div class="row mb-4">
            <div class="col-lg-12">

                <div class="col-lg-12">
                    <div class="card card-block card-stretch custom-scroll">
                        <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-3">
                            <div class="caption">
                                <h4 class="font-weight-bold mb-2">All Deposits</h4>
                            </div>
                          
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">



                                <table class="table mb-0 text-nowrap">
                                    <thead class="table-light">
                                        <tr>
                                            <th scope="col" class="border-0">Sn</th>
                                            <th scope="col" class="border-0">Username</th>
                                            <th scope="col" class="border-0">Amount</th>
                                            <th scope="col" class="border-0">Wallet Address</th>
                                            <th scope="col" class="border-0">Status</th>
                                            <th scope="col" class="border-0">Timestamp</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="align-middle border-top-0">
                                                    <div class="d-flex align-items-center">
                                                        <h5 class="mb-0"> <?php echo e($loop->iteration); ?> </h5>
                                                    </div>
                                                </td>
                                                <td class="align-middle border-top-0">
                                                    <?php echo e($dep->user->username); ?>

                                                </td>
                                                <td class="align-middle border-top-0">
                                                    <?php echo e(depositAmount($dep->amount)); ?>

                                                </td>
                                                <td class="align-middle border-top-0">
                                                    <?php echo e($dep->wallet); ?>

                                                </td>
                                                <td class="align-middle border-top-0">
                                                    <?php echo depositStatus($dep->status); ?>

                                                </td>

                                                <td class="align-middle border-top-0">
                                                    <?php echo e($dep->created_at); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-center  pt-3">
                                    <?php echo e($deposits->links('pagination::bootstrap-4')); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row pt-2">
            <div class="col-lg-8">
                <div class="row">
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.admin02', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hybrid-coin\resources\views/admin/deposit_history.blade.php ENDPATH**/ ?>