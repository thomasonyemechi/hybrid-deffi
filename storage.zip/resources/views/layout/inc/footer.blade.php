<footer>
            <div class="footer-area-three">
                <div class="container">
              
                    {{-- <div class="footer-top">
                        <div class="row">
                            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
                                <div class="footer-widget">
                                    <h4 class="fw-title">Use Case</h4>
                                    <div class="footer-link">
                                        <ul class="list-wrap">
                                            <li><a href="contact.html">For teams</a></li>
                                            <li><a href="contact.html">For blog writer</a></li>
                                            <li><a href="contact.html">For social media</a></li>
                                            <li><a href="contact.html">Report & Outage</a></li>
                                            <li><a href="contact.html">Email Marketing</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
                                <div class="footer-widget">
                                    <h4 class="fw-title">company</h4>
                                    <div class="footer-link">
                                        <ul class="list-wrap">
                                            <li><a href="contact.html">Affiliate program</a></li>
                                            <li><a href="login.html">Account</a></li>
                                            <li><a href="contact.html">Invite a friend</a></li>
                                            <li><a href="contact.html">Privacy policy</a></li>
                                            <li><a href="contact.html">Terms of use</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-2 col-lg-3 col-md-4 col-sm-6">
                                <div class="footer-widget">
                                    <h4 class="fw-title">Product</h4>
                                    <div class="footer-link">
                                        <ul class="list-wrap">
                                            <li><a href="index.html">DEX. AI</a></li>
                                            <li><a href="work.html">Our work</a></li>
                                            <li><a href="about.html">About us</a></li>
                                            <li><a href="help.html">Support</a></li>
                                            <li><a href="contact.html">Contact us</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                                <div class="footer-widget">
                                    <h4 class="fw-title">Need help?</h4>
                                    <div class="footer-contact">
                                        <a href="tel:0123456789" class="phone">+(1) 123 656 7866</a>
                                        <a href="mailto:dex.aiinfotive@.com" class="email">dex.ai infotive@.com</a>
                                        <a href="mailto:dex.aiinfotive@.com" class="email">webdexai.com</a>
                                    </div>
                                    <div class="footer-social">
                                        <ul class="list-wrap">
                                            <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                            <li><a href="#"><i class="fab fa-pinterest-p"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-4 col-md-6">
                                <div class="footer-widget">
                                    <div class="footer-newsletter">
                                        <h6 class="title">Join our community</h6>
                                        <p>Meet and learn from 70k+ creators & companies</p>
                                        <a href="#" class="btn btn-two">join the community</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> --}}
                    <div class="footer-bottom-three">
                        <div class="row align-items-center">
                            <div class="col-lg-8">
                                <div class="copyright-text">
                                    <p>Copyright © {{date('Y')}} {{ env('APP_NAME') }} All rights reserved.</p>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="footer-menu">
                                    <ul class="list-wrap">
                                        <li><a href="#">Terms & Conditions</a></li>
                                        <li><a href="#">Refund Policy</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>